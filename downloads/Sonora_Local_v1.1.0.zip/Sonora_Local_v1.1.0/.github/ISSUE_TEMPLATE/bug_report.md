---
name: Relatar um problema
about: Informe um erro para ajudar a melhorar o Sonora
title: "[Bug]: "
labels: bug
---

### O que aconteceu?

### Como reproduzir?
1.
2.
3.

### O que você esperava?

### Navegador e sistema

### Console do navegador (se houver)
