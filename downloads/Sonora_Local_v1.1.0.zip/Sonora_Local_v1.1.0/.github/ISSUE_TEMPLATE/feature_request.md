---
name: Sugerir recurso
about: Compartilhe uma ideia para o Sonora
title: "[Ideia]: "
labels: enhancement
---

### Qual é a ideia?

### Que problema ela resolveria?

### Como você imagina o funcionamento?
